package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {
    Button previous, next, pause;
    TextView songTextLabel;
    SeekBar seekBar;
    static MediaPlayer myMediaplayer;
    int position;
    ArrayList<File> mySongs;
    Thread updateseekBar;
    String sname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        previous = (Button) findViewById(R.id.previous);
        next = (Button) findViewById(R.id.next);
        pause = (Button) findViewById(R.id.pause);
        songTextLabel = (TextView) findViewById(R.id.textSongName);
        seekBar = (SeekBar) findViewById(R.id.seekbar1);
        getSupportActionBar().setTitle("Now Playing");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        updateseekBar = new Thread() {
            @Override
            public void run() {
                int totalDuration = myMediaplayer.getDuration();
                int currentPostiion = 0;
                while (currentPostiion < totalDuration) {
                    try {
                        sleep(500);
                        currentPostiion = myMediaplayer.getCurrentPosition();
                        seekBar.setProgress(currentPostiion);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        if (myMediaplayer != null) {
            myMediaplayer.stop();
            myMediaplayer.release();

        }
        Intent i = getIntent();
        Bundle bundle = i.getExtras();
        mySongs = (ArrayList) bundle.getParcelableArrayList("songs");
        sname = mySongs.get(position).getName().toString();
        String songName = i.getStringExtra("songname");
        songTextLabel.setText(songName);
        songTextLabel.setSelected(true);
        position = bundle.getInt("pos", 0);
        Uri uri = Uri.parse(mySongs.get(position).toString());
        myMediaplayer = MediaPlayer.create(getApplicationContext(), uri);
        myMediaplayer.start();
        seekBar.setMax(myMediaplayer.getDuration());
        updateseekBar.start();
        seekBar.getProgressDrawable().setColorFilter(getResources().getColor(R.color.black), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(getResources().getColor(R.color.black),PorterDuff.Mode.SRC_IN);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                myMediaplayer.seekTo(seekBar.getProgress());
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBar.setMax(myMediaplayer.getDuration());
                if (myMediaplayer.isPlaying()){
                    pause.setBackgroundResource(R.drawable.ic_play);
                    myMediaplayer.pause();
                }else
                {
                    pause.setBackgroundResource(R.drawable.ic_pause);
                    myMediaplayer.start();
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myMediaplayer.stop();
                myMediaplayer.release();
                position = ((position+1)%mySongs.size());
                Uri uri = Uri.parse(mySongs.get(position).toString());
                myMediaplayer = MediaPlayer.create(getApplicationContext(),uri);
                sname = mySongs.get(position).getName().toString();
                songTextLabel.setText(sname);
                myMediaplayer.start();
            }
        });
      previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myMediaplayer.stop();
               myMediaplayer.release();
               position=((position-1)<0)?(mySongs.size()-1):(position-1);
                Uri uri =  Uri.parse(mySongs.get(position).toString());
                myMediaplayer= MediaPlayer.create(getApplicationContext(),uri);
                sname = mySongs.get(position).getName().toString();
               songTextLabel.setText(sname);
                myMediaplayer.start();//

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            onBackPressed();
        }


        return super.onOptionsItemSelected(item);
    }
}
