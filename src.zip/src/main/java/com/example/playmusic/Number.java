package com.example.playmusic;

public class Number {
    String numberid;
    String numberValue;
    String sppinnerValue;

    public Number(){

}

    public Number(String numberid, String numberValue, String sppinnerValue) {
        this.numberid = numberid;
        this.numberValue = numberValue;
        this.sppinnerValue = sppinnerValue;
    }

    public String getNumberid() {
        return numberid;
    }

    public String getNumberValue() {
        return numberValue;
    }

    public String getSppinnerValue() {
        return sppinnerValue;
    }
}
