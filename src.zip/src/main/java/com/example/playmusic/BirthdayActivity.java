package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class BirthdayActivity extends AppCompatActivity {

   DatePicker datePicker;
    TextView mydate;
    Button prev,next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_birthday);
        getSupportActionBar().hide();

        datePicker=(DatePicker) findViewById(R.id.datePicker);
        mydate=(TextView)findViewById(R.id.mydate);
        prev=(Button)findViewById(R.id.prev);
        next=(Button)findViewById(R.id.next);

        //  datePicker.setOnDateChangedListener(new CalendarView.OnDateChangeListener() {
           // @Override
          //  public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
        //        String date=(month +1)+ "/" + dayOfMonth + "/" + year;
         //       mydate.setText(date);
          //  }
        //});
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(BirthdayActivity.this,MainActivity.class);
                startActivity(intent);
                Toast.makeText(BirthdayActivity.this,"Don't Worry" , Toast.LENGTH_SHORT).show();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(BirthdayActivity.this,RegisterActivity.class);
                startActivity(intent);
                Toast.makeText(BirthdayActivity.this,"Register here" , Toast.LENGTH_SHORT).show();
            }
        });


    }
}
