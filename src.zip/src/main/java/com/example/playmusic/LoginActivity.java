package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    TextView textview4 , textview5;
    Button prev,next;
    EditText email,password;
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        textview4=(TextView)findViewById(R.id.textview4);
        textview5=(TextView)findViewById(R.id.textview5);
        prev=(Button)findViewById(R.id.prev);
        next=(Button)findViewById(R.id.next);
        email=(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);

        preferences=getSharedPreferences("UserInfo", 0);


        String text="Forgot password? Get help signing in.";
        String text1="Log in with Phone Number>";

        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan1 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(LoginActivity.this,HelpActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };

        ss.setSpan(clickableSpan1,17,37, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview4.setText(ss);
        textview4.setMovementMethod(LinkMovementMethod.getInstance());
        SpannableString ss1 = new SpannableString(text1);
        ClickableSpan clickableSpan2 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(LoginActivity.this,PhoneloginActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLACK);
                ds.setUnderlineText(false);
            }
        };

        ss1.setSpan(clickableSpan2,0,25, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview5.setText(ss1);
        textview5.setMovementMethod(LinkMovementMethod.getInstance());

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uenamil= email.getText().toString();
                String upassword=password.getText().toString();

                String registeredEmail=preferences.getString("email","");
                String registeredPassword=preferences.getString("password","");
                if(uenamil.equals(registeredEmail) && upassword.equals(registeredPassword))
                {
                    Toast.makeText(LoginActivity.this, "Welcome from PlayMuzic", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this,Home.class);
                    intent.putExtra("EMAIL",uenamil);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Ener Valid Email & password", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
