package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApiNotAvailableException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

public class PhoneActivity extends AppCompatActivity {
    TextView textview3;
    Button prev , next;
    Spinner sppinner;
    EditText number;
    SharedPreferences preferences;
    DatabaseReference databaseReferenceNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone);
        databaseReferenceNumber= FirebaseDatabase.getInstance().getReference("Number Registered");

        textview3=(TextView)findViewById(R.id.textview3);
        prev=(Button)findViewById(R.id.prev);
        next=(Button)findViewById(R.id.next);
        sppinner=(Spinner)findViewById(R.id.sppinner);
        number=(EditText)findViewById(R.id.number);

        preferences=getSharedPreferences("UserInfo", 0);

        String text="By sigining up, you confirm that you agree to our Terms of Use and have read and understood our Privancy Policy.You will receive an SMS to confirm your phone number SMS fee may apply.";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan1 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(PhoneActivity.this,TermsActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };
        ClickableSpan clickableSpan2 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(PhoneActivity.this,PrivancyActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };
        ss.setSpan(clickableSpan1,50,62, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(clickableSpan2,96,112, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview3.setText(ss);
        textview3.setMovementMethod(LinkMovementMethod.getInstance());

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  =new Intent(PhoneActivity.this,RegisterActivity.class);
                startActivity(intent);

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numberValue=number.getText().toString();
                if(numberValue.length()>9)
                {

                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("number",numberValue);
                    editor.apply();
                    addArtist();

                    //Toast.makeText(PhoneActivity.this,"Registered",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(PhoneActivity.this,"Password should more than 9 ",Toast.LENGTH_SHORT).show();
                }

            }
        });
        String [] number1={"+91","+92","+93","+94","+95"};
        ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,number1);
        sppinner.setAdapter(adapter);


    }
    private void addArtist()
    {
        String numberValue1=number.getText().toString();
        String sppinnerValue=sppinner.getSelectedItem().toString();

        if(!TextUtils.isEmpty(numberValue1)){
            String id =databaseReferenceNumber.push().getKey();
            Number number12=new Number(id,numberValue1,sppinnerValue);
            databaseReferenceNumber.child(id).setValue(number12);
            Intent intent  =new Intent(PhoneActivity.this,PhoneloginActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Registered", Toast.LENGTH_SHORT).show();



        }
        else{
            Toast.makeText(this, "You should enter a number more than 9 ", Toast.LENGTH_SHORT).show();
        }
    }
}
