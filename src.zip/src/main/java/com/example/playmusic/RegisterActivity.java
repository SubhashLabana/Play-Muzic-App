package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    TextView textview1;
    TextView textview2;
    Button prev , next;
    EditText email,password;
   //private FirebaseAuth firebaseauth;

    SharedPreferences preferences;
    DatabaseReference databaseReference1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        databaseReference1= FirebaseDatabase.getInstance().getReference("Emails");
  //      firebaseauth = FirebaseAuth.getInstance();
        textview1 =(TextView)findViewById(R.id.textview1);
        textview2 =(TextView)findViewById(R.id.textview2);
        prev=(Button)findViewById(R.id.prev);
        next=(Button)findViewById(R.id.next);
        email=(EditText)findViewById(R.id.email);
        password=(EditText)findViewById(R.id.password);
        preferences=getSharedPreferences("UserInfo", 0);

        String text= "By sigining up, you confirm that you agree to our Terms of Use and have read and understood our Privancy Policy.";
        String text2 ="Sign up with phone";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan1 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(RegisterActivity.this,TermsActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };
        ClickableSpan clickableSpan2 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(RegisterActivity.this,PrivancyActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };
        ss.setSpan(clickableSpan1,50,62, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(clickableSpan2,96,112, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview1.setText(ss);
        textview1.setMovementMethod(LinkMovementMethod.getInstance());

        SpannableString ss1 =new SpannableString(text2);
        ClickableSpan clickableSpan3 = new ClickableSpan() {


            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(RegisterActivity.this,PhoneActivity.class);
                startActivity(intent);
                finish();
            }
            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.WHITE);
                ds.setUnderlineText(false);

            }
        };
        ss1.setSpan(clickableSpan3,1,18,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview2.setText(ss1);
        textview2.setMovementMethod(LinkMovementMethod.getInstance());

    prev.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent =new Intent(RegisterActivity.this,BirthdayActivity.class);
            startActivity(intent);
        }
    });
    next.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            String emailValue=email.getText().toString();
            String passwordValue=password.getText().toString();

            if(emailValue.length()>1 && passwordValue.length()>4)
            {
                SharedPreferences.Editor editor=preferences.edit();
                editor.putString("email",emailValue);
                editor.putString("password",passwordValue);
                editor.apply();
                //validate();
                addEmail();

            }
           else
            {
                Toast.makeText(RegisterActivity.this,"Please enter value",Toast.LENGTH_SHORT).show();
            }
        }
    });
    }
   private  void addEmail(){

        String emailValue=email.getText().toString();
        String passwordValue=password.getText().toString();
        if (!TextUtils.isEmpty(emailValue)&& !TextUtils.isEmpty(passwordValue))
        {
            String id =databaseReference1.push().getKey();
            Email emails=new Email(id,emailValue,passwordValue);
            databaseReference1.child(id).setValue(emails);
            Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
            startActivity(intent);
            Toast.makeText(RegisterActivity.this, "Registration Successfull", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "You should enter the field", Toast.LENGTH_SHORT).show();
        }
    }
    private Boolean validate(){
        Boolean result = false;

        String emailValue=email.getText().toString();
        String passValue=password.getText().toString();
        if (emailValue.isEmpty() || passValue.isEmpty()){
            Toast.makeText(this, "Required all fields", Toast.LENGTH_SHORT).show();
        }
        else
        {
            result =true;

        }
        return result;
    }
}
