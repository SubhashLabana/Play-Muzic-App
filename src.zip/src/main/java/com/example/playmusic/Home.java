package com.example.playmusic;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.provider.MediaStore;
import android.provider.Settings;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private ArrayList<SongInfo> _songs = new ArrayList<SongInfo>();
    RecyclerView recyclerView;
    SeekBar seekBar;
    SongAdapter songAdapter;
    MediaPlayer mediaPlayer;
    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar=null;
    //private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer =(DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toogle= new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawer.setDrawerListener(toogle);
        toogle.syncState();
         navigationView = (NavigationView) findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.

    //    NavigationUI.setupWithNavController(navigationView, navController);
        navigationView.setNavigationItemSelectedListener(Home.this);
        recyclerView = (RecyclerView)findViewById(R.id.recycler_view);
        seekBar = (SeekBar)findViewById(R.id.seekbar);
        SongInfo s = new SongInfo("Cheap Thrills" ,"Sia","https://www.android-examples.com/wp-content/uploads/2016/04/Thunder-rumble.mp3");
       _songs.add(s);
        songAdapter = new SongAdapter(this,_songs);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(songAdapter);
        songAdapter.setOnitemClickListener(new SongAdapter.OnitemClickListener() {
            @Override
            public void onItemClick(final Button b, View v, SongInfo obj, int position) {
                try {

                if (b.getText().toString().equals("Stop"))
                {
                    b.setText("Play");
                    mediaPlayer.stop();
                    mediaPlayer.reset();
                    mediaPlayer.release();;
                    mediaPlayer = null;
                }else {
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setDataSource(obj.getSongUrl());
                    mediaPlayer.prepareAsync();
                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mp.start();
                            b.setText("Stop");
                        }
                    });
                }
                }catch (IOException e){

                }
            }
        });

 //       checkPermission();
    }
    @Override
    public void onBackPressed(){
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START))
        {
            drawer.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(Home.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @SuppressWarnings("StatementmentWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item){
        int id = item.getItemId();
        switch (id)
        {
            case R.id.nav_home:
                Intent intent = new Intent(Home.this,Home.class);
                startActivity(intent);
                break;

            case R.id.nav_gallery:
                Intent inten = new Intent(Home.this,Gallery.class);
                startActivity(inten);
                break;

            case R.id.nav_slideshow:
                Intent inte = new Intent(Home.this,Slidshow.class);
                startActivity(inte);
                break;

            case R.id.nav_tools:
                Intent n = new Intent(Home.this,Tools.class);
                startActivity(n);
                break;
        }
        DrawerLayout drawer = (DrawerLayout)findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
  // private void checkPermission(){
       // if (Build.VERSION.SDK_INT >= 23) {
          //  if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            //    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1234);
          //      return;
        //    }
      //  }else
        //{
       //     loadSongs();
     //   }


   // }

  //  @Override
   // public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //switch (requestCode){
            ///case 1234:
               // if (grantResults[0]==PackageManager.PERMISSION_GRANTED){
                  //  loadSongs();
                //}else{
                //    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
              //      checkPermission();
            //    }
          //      break;
        //        default:
       //             super.onRequestPermissionsResult(requestCode, permissions, grantResults);
      //  }

    //}
   // private  void loadSongs(){
       // Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
       // String selection = MediaStore.Audio.Media.IS_MUSIC +"!=0";
       // Cursor cursor= getContentResolver().query(uri,null,selection,null,null);
       // if (cursor!=null){
            //if (cursor.moveToFirst()){
                //do {


                //String name= cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME));
                //String artist= cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
               // String url1= cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                 //   SongInfo s = new SongInfo(name,artist,url1);
               //     _songs.add(s);
             //   }while(cursor.moveToNext());

           // }
         //   cursor.close();
       //     songAdapter = new SongAdapter(this,_songs);
     //   }
   // }
}
