package com.example.playmusic;

public class Email {
    String emailId;
    String emailAdd;
    String emailPass;

    public Email()
    {

    }

    public Email(String emailId, String emailAdd, String emailPass) {
        this.emailId = emailId;
        this.emailAdd = emailAdd;
        this.emailPass = emailPass;
    }

    public String getEmailId() {
        return emailId;
    }

    public String getEmailAdd() {
        return emailAdd;
    }

    public String getEmailPass() {
        return emailPass;
    }

    public static class SongInfo {
        public String SongName,artistsName,songurl;

        public SongInfo(String songName, String artistsName, String songurl) {
            SongName = songName;
            this.artistsName = artistsName;
            this.songurl = songurl;
        }


    }
}
