package com.example.playmusic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PhoneloginActivity extends AppCompatActivity {

    TextView textview6;
    Button prev,next;
    Spinner sppinner;
    EditText number;
    SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_phonelogin);
        getSupportActionBar().hide();

        textview6=(TextView)findViewById(R.id.textview6);
        prev=(Button)findViewById(R.id.prev);
        next=(Button)findViewById(R.id.next);
        sppinner=(Spinner)findViewById(R.id.sppinner);
        number=(EditText)findViewById(R.id.number);
        preferences=getSharedPreferences("UserInfo", 0);
        String text="Log in with Email>";

        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan1 =new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent =new Intent(PhoneloginActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLACK);
                ds.setUnderlineText(false);
            }
        };

        ss.setSpan(clickableSpan1,0,18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textview6.setText(ss);
        textview6.setMovementMethod(LinkMovementMethod.getInstance());

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(PhoneloginActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unumber=number.getText().toString();

                String registeredNumber=preferences.getString("number","");
                if(unumber.equals(registeredNumber))
                {
                    Toast.makeText(PhoneloginActivity.this,"Welcome from PlayMuzic" ,Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PhoneloginActivity.this,Home.class);
                    intent.putExtra("NUMBER",unumber);
                    startActivity(intent);


                }
                else
                {
                    Toast.makeText(PhoneloginActivity.this,"Please enter Valid value" ,Toast.LENGTH_SHORT).show();
                }

            }
        });
        String [] number1={"+91","+92","+93","+94","+95"};
        ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,number1);
        sppinner.setAdapter(adapter);
    }
}
